package com.anganwaadi.anganwaadi_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnganwaadiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnganwaadiServerApplication.class, args);
	}

}
